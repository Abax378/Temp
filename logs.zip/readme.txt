Note that the .ps1 file used to generate these logs is called

ZIP_movies_ERR.ps1

and is identical to the sample file 

demo_ext_err.ps1

provided for this bug report.